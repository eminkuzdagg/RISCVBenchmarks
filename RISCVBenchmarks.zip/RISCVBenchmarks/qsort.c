#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ARRAY_SIZE 10000000  // Dizi boyutu (10 milyon eleman)
#define NUM_OPERATIONS 1000000000  // Toplam işlem sayısı (1 milyar işlem)

void perform_operations() {
    int a = 10, b = 5;
    for (int i = 0; i < NUM_OPERATIONS; i++) {
        // Basit bir işlem yap (örneğin, toplama ve çıkarma)
        a = a + b;
        a = a - b;
    }
}

int main() {
    // Dizi oluştur
    int *arr = (int *)malloc(ARRAY_SIZE * sizeof(int));
    if (arr == NULL) {
        printf("Hafıza tahsisi başarısız!\n");
        return 1;
    }

    // Rastgele sayılarla dizi doldur
    srand(time(NULL));
    for (int i = 0; i < ARRAY_SIZE; i++) {
        arr[i] = rand();
    }

    // Başlangıç zamanı
    clock_t start_time = clock();

    // Perform operations
    perform_operations();

    // Bitiş zamanı
    clock_t end_time = clock();

    // Geçen süreyi hesapla (milisaniye cinsinden)
    double elapsed_time = ((double)(end_time - start_time) / CLOCKS_PER_SEC) * 1000.0;

    // MIPS hesapla
    double mips = (double)NUM_OPERATIONS / (elapsed_time * 1e-3 * 1e6);

    printf("Geçen Süre: %.2f milisaniye\n", elapsed_time);
    printf("MIPS Değeri: %.2f\n", mips);

    // Belleği serbest bırak
    free(arr);

    return 0;
}

