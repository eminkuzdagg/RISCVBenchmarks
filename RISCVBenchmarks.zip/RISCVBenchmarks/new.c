#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>
#include <immintrin.h>
#include <time.h>

#define PI 3.14159265358979323846

// Function to perform FFT using Cooley-Tukey algorithm
void fft(complex double* a, int n) {
    // Bit-reversal permutation
    for (int i = 0, j = 0; i < n; i++) {
        if (i < j) {
            complex double temp = a[i];
            a[i] = a[j];
            a[j] = temp;
        }
        int k = n / 2;
        while (k <= j) {
            j -= k;
            k /= 2;
        }
        j += k;
    }

    // Cooley-Tukey FFT
    for (int step = 1; step < n; step *= 2) {
        for (int offset = 0; offset < n; offset += 2 * step) {
            for (int k = 0; k < step; k++) {
                complex double t = cexp(-2.0 * I * PI * k / (2 * step)) * a[offset + step + k];
                a[offset + step + k] = a[offset + k] - t;
                a[offset + k] += t;
            }
        }
    }
}

// Function to generate a random input signal
void generate_random_signal(complex double* signal, int size) {
    for (int i = 0; i < size; i++) {
        signal[i] = (rand() / (double)RAND_MAX) + I * (rand() / (double)RAND_MAX);
    }
}

int main() {
    const int n = 1024;  // Size of the input signal (should be a power of 2)

    // Allocate memory for input and output signals
    complex double* input_signal = (complex double*)malloc(n * sizeof(complex double));
    complex double* output_signal = (complex double*)malloc(n * sizeof(complex double));

    // Generate a random input signal
    srand(time(NULL));
    generate_random_signal(input_signal, n);

    // Measure the FFT time
    clock_t start_time = clock();
    fft(input_signal, n); // Perform FFT
    clock_t end_time = clock();

    // Print the elapsed time
    double elapsed_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;
    printf("FFT time: %lf seconds\n", elapsed_time);

    // Free allocated memory
    free(input_signal);
    free(output_signal);

    return 0;
}

