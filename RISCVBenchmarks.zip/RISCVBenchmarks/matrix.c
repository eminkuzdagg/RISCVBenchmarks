#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <assert.h>

// Matrix multiplication function
void matrix_multiply(int *A, int *B, int *C, int m, int n, int p) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < p; j++) {
            C[i*p + j] = 0;
            for (int k = 0; k < n; k++) {
                C[i*p + j] += A[i*n + k] * B[k*p + j];
            }
        }
    }
}

int main() {
    // Define matrix dimensions
    const int m = 1024;
    const int n = 1024;
    const int p = 1024;

    // Allocate memory for matrices
    int *A = (int *)malloc(m * n * sizeof(int));
    int *B = (int *)malloc(n * p * sizeof(int));
    int *C = (int *)malloc(m * p * sizeof(int));
    int *D = (int *)malloc(m * p * sizeof(int));  // Correct result for verification

    // Initialize matrices A and B with random values
    srand(time(NULL));
    for (int i = 0; i < m * n; i++) {
        A[i] = rand() % 100;
    }
    for (int i = 0; i < n * p; i++) {
        B[i] = rand() % 100;
    }

    // Compute the correct result for verification
    matrix_multiply(A, B, D, m, n, p);

    // Measure time for matrix multiplication
    clock_t start_time = clock();
    matrix_multiply(A, B, C, m, n, p);
    clock_t end_time = clock();

    // Verify the result
    for (int i = 0; i < m * p; i++) {
        assert(C[i] == D[i]);
    }

    // Print the elapsed time
    double elapsed_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;
    printf("Matrix multiplication time: %lf seconds\n", elapsed_time);

    // Free allocated memory
    free(A);
    free(B);
    free(C);
    free(D);

    return 0;
}

